$(".homecard a").addClass("hidden");
$('.homecard').hover(
  function () {
    $(this).find("a").addClass("animated fadeIn");
    $(this).find("a").removeClass("hidden");
    $(this).find("h2").css("color","#333333");
    $("body").appned()
  }, 
  function () {
    $(this).find("a").removeClass("animated fadeIn");
    $(this).find("a").addClass("hidden");
    $(this).find("h2").css("color","#ccc");
  }
);

